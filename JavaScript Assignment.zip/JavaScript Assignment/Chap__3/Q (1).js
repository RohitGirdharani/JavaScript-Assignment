var age = 20;
alert("Iam " + age + " Years old");