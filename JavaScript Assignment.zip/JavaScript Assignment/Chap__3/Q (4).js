var visitorsName = "John Doe";
var productTitle = "T-shirt";
var Quantity = 5;

document.write("<strong>" + visitorsName + " </strong> ordered <strong>" + Quantity + " " + productTitle + "(s)</strong> on XYZ Clothing store.")