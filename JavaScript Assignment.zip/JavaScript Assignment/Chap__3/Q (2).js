var visitors = 10;
alert("You have visited this site " + visitors + " times");