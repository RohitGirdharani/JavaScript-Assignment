var birthYear = 2000;
document.write("My birth year is " + birthYear + "<br/> Data type of my declared variable is number");