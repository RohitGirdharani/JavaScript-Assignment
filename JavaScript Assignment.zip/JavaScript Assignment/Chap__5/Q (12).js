var radius = 20;
var circumference = 2 * 3.142 * radius;
var area = 3.142 * (radius * radius);

document.write("raduis of the cricle: " + radius + "<br />");
document.write("Circumference of the circle: " + circumference + "<br />");
document.write("The area of the circle: " + area + "<br />");