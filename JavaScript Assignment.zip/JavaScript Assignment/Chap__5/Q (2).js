var num1 = 1;
var num2 = 2;
var sum = num1 + num2;
var sub = num1 - num2;
var multiply = num1 * num2;
var modulus = num1 % num2;

document.write("sum of " + num1 + " and " + num2 + " is " + sum);
document.write("subtract of " + num1 + " and " + num2 + " is " + sub);
document.write("multiply of " + num1 + " and " + num2 + " is " + multiply);
document.write("modulus of " + num1 + " and " + num2 + " is " + modulus);