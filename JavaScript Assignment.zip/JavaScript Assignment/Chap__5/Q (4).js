var ticketPrice = 600;
var numberOfTicketPurchased = 5;
var totalPrice = ticketPrice * numberOfTicketPurchased;

document.write("Total cost to buy " + numberOfTicketPurchased + "tickets to a movie is " + totalPrice + "PKR.");