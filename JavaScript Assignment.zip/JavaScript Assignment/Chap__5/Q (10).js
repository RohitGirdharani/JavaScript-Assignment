var num = 10;
var expression = num + 5 * 10 / 2;