var totalMarks = 980;
var marksObtained = 804;
var percentage = (marksObtained / totalMarks) * 100;

document.write("Total Marks:" + totalMarks);
document.write("<br/> marks obtained: " + marksObtained);
document.write("<br/> Percentage: " + percentage);