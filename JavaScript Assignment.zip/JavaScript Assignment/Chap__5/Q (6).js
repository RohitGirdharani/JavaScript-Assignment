var celsiusTemperature = 32;

var toFahrenheit = (celsiusTemperature * 9 / 5) + 32;
document.write("Temperature in Fahrenheit: " + toFahrenheit);

var toCelsius = (toFahrenheit - 32) * 5 / 9;
document.write("Temperature in celsius " + toCelsius);