var currentYear = 2020;
var birthYear = 2000;
var yourAge = currentYear - birthYear;

document.write(" Current year: " + currentYear + "<br/>");
document.write(" Current year: " + birthYear + "<br/>");
document.write(" Current year: " + yourAge + "<br/>");