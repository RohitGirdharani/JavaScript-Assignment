var num1 = 1;
var num2 = 2;
var sum = num1 + num2;

document.write("sum of " + num1 + " and " + num2 + " is " + sum);