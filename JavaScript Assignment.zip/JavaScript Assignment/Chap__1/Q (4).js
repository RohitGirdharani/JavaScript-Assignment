alert("Welcome to JS land");
alert("Happy Coding \n  Prevent this page from creating additional dialogs.");