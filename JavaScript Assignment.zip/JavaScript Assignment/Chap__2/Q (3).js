var Message = "Hello, World!";
alert(Message);