var string = "▬▬▬▬▬▬▬▬▬ஜ۩۞۩ ஜ▬▬▬▬▬▬▬▬▬ ";
alert(string);