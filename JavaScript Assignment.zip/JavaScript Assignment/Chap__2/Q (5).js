var pizza = "PIZZA \nPIZZ\nPIZZ\nPIZ\nPI\nP";
alert(pizza);