var book = "A smarter way to learn JavaScript";
alert("Iam trying to learn from the book " + book);