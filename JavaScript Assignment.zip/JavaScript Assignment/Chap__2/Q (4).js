var userName = "Jhone Doe";
var age = 15;
var greet = "Certified Mobile Application Development";

alert(userName);
alert(age + " year old");
alert(greet);