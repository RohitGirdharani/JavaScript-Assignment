for (var i = 0; i < 15; i++) {
    document.write((i + 1) + ",");
}
document.write("<br/>");

for (var i = 15; i > 0; i--) {
    document.write((i) + ",");
}
document.write("<br/>");

for (var i = 1; i < 15; i++) {
    if (i % 2 == 0)
        document.write((i) + ",");
}
document.write("<br/>");

for (var i = 1; i < 15; i++) {
    if (i % 3 == 0)
        document.write((i) + ",");
}
document.write("<br/>");

for (var i = 1; i < 15; i++) {
    if (i % 2 == 0)
        document.write((i) + "k,");
}
document.write("<br/>");