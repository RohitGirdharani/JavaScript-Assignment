for (var i = 0; i < 20; i++) {
    document.write(5 * (i + 1) + "<br/>");
}