var fruits = ["apples", "banana", "graps", "orange"];
document.write(fruits + "<br/>");
for (var i = 0; i < fruits.length; i++) {
    document.write("element at index" + i + " is " + fruits[i] + "<br/>");
}