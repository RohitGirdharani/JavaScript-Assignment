var password = "Password!";
var user = prompt("Enter the password");
if (user === password) {
    alert("Correct! The password you entered matches the original password");
} else {
    alert("Incorrect password");
}