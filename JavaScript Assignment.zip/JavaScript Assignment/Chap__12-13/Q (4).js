var user = prompt("Enter one character");
if (user == 'a' || user == 'e' || user == 'i' || user == 'o' || user == 'u') {
    alert("yes these are vowels");
}