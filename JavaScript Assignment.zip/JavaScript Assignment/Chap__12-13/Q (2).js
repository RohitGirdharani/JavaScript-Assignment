var num = 10;
var num1 = 20;

if (num > num1) {
    alert(num);
} else {
    alert(num1);
}

if (num == num1) {
    alert("Both are equal");
}