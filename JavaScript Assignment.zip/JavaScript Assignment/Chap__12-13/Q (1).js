var char = prompt("Enter character");

if (char >= 'A' && char <= 'Z') {
    alert("Upper case!")
} else {
    alert("Lower case!");
}