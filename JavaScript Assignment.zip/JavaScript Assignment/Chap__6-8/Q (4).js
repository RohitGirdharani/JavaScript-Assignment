var table = prompt("Enter the number for table ");
var intTable = parseInt(table);

if (intTable) {

    document.write(" The table of 5: " + intTable * 1 + "<br/>");
    document.write(" The table of 5: " + intTable * 2 + "<br/>");
    document.write(" The table of 5: " + intTable * 3 + "<br/>");
    document.write(" The table of 5: " + intTable * 4 + "<br/>");
    document.write(" The table of 5: " + intTable * 5 + "<br/>");
    document.write(" The table of 5: " + intTable * 6 + "<br/>");
    document.write(" The table of 5: " + intTable * 7 + "<br/>");
    document.write(" The table of 5: " + intTable * 8 + "<br/>");
    document.write(" The table of 5: " + intTable * 9 + "<br/>");
    document.write(" The table of 5: " + intTable * 10 + "<br/>");

} else {
    intTable = 5;
    document.write(" The table of 5: " + intTable * 1 + "<br/>");
    document.write(" The table of 5: " + intTable * 2 + "<br/>");
    document.write(" The table of 5: " + intTable * 3 + "<br/>");
    document.write(" The table of 5: " + intTable * 4 + "<br/>");
    document.write(" The table of 5: " + intTable * 5 + "<br/>");
    document.write(" The table of 5: " + intTable * 6 + "<br/>");
    document.write(" The table of 5: " + intTable * 7 + "<br/>");
    document.write(" The table of 5: " + intTable * 8 + "<br/>");
    document.write(" The table of 5: " + intTable * 9 + "<br/>");
    document.write(" The table of 5: " + intTable * 10 + "<br/>");
}