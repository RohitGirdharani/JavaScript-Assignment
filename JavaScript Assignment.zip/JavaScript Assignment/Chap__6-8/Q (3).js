var user = prompt("enter your name");
alert("Welcome, " + user);