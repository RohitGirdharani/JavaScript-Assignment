var a = 2;
var b = 1;
var result = --a - --b + ++b + b--;
//          //1     //0  //1    //1

document.write("result " + result);