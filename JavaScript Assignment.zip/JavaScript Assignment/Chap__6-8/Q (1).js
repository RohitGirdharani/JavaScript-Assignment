var a = 10;
document.write(" the value a: " + a + "<br/>");
document.write("Value ++a " + (++a) + "<br/>");
document.write("Value a " + (a) + "<br/>");

document.write("Value a++ " + (a++) + "<br/>");
document.write("Value a " + (a) + "<br/>");

document.write("Value --a " + (--a) + "<br/>");
document.write("Value a " + (a) + "<br/>");

document.write("Value a-- " + (a--) + "<br/>");
document.write("Value a " + (a)) + "<br/>";