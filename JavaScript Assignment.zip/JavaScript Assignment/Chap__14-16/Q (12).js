var arr = ["this", "is", "my", "cat"];
document.write(arr + "<br/>");
document.write(arr.join(" "));