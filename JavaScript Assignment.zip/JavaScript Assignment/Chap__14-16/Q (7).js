var arr = ["SSC", "HSC", "BCS", "BS", "BCOM", "MS", "M. PHIL", "PHD"];

document.write("1) " + arr[0] + "<br />2) " + arr[1] + "<br />3) " + arr[2] + "<br />4) " + arr[3] + "<br />5)" + arr[4] + "<br />6) " + arr[5] + "<br />7)" + arr[6] + "<br />8)" + arr[7]);