var cityList = ["Karachi", "Lahore", "Islamabad", "Quetta", "Peshawar"];
var selectedCities = cityList.splice(2, 2);
document.write(cityList + "<br/>");
document.write(selectedCities + "<br/>");