var marks = [100, 400, 200, 123];
document.write(marks + "<br/>");
document.write(marks.sort() + "<br/>");