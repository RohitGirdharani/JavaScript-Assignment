var arr = [];
arr.shift("moniter");
arr.shift("printer");
arr.shift("mouse");
arr.shift("keyboard");

document.write(arr + "<br/>");

//shift and unshifts are the concept for the first in and first out!