var arr = [];
arr.shift("moniter");
arr.shift("printer");
arr.shift("mouse");
arr.shift("keyboard");

document.write(arr + "<br/>");

arr.pop();


//the arr.pop will pop the elements from the end so it will be first in last out!