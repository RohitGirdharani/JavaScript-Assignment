var user = prompt("Enter the number");
user = parseInt(user);

if (user % 3 == 0) {
    alert("it is odd");
} else if (user % 2 == 0) {
    alert("it is even");
}