var city = prompt("Enter the city");
if (city === "Karachi") {
    alert("Welcome to the city of lights");
}