var color = prompt("enter the color: ");
if (color == "red") {
    alert("Must stop!");
} else if (color == "yellow") {
    alert("ready to move");
} else if (color == "green") {
    alert("Move now!");
}