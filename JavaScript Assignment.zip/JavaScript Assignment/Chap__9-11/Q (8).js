var user = prompt("Enter the number");
user = parseInt(user);

if (user % 3 == 0) {
    alert("Yes it is divisble by 3");
} else {
    alert("no it is not divisble by 3");
}