var gender = prompt("enter your gender");
if (gender == "male") {
    alert("Good morning sir");
} else {
    alert("Good morning ma'am");
}